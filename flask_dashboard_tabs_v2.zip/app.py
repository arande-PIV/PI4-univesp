
from flask import Flask, render_template
from markupsafe import Markup
import json

app = Flask(__name__)

ALUNOS = [
  {
    "id": 1,
    "nome": "Camila",
    "media": 78,
    "cores": 74,
    "animais": 70,
    "comidas": 81,
    "evolucao": [
      75,
      75,
      77,
      78,
      79,
      80
    ],
    "tentativas": []
  },
  {
    "id": 2,
    "nome": "Pedro",
    "media": 70,
    "cores": 75,
    "animais": 73,
    "comidas": 62,
    "evolucao": [
      68,
      68,
      68,
      69,
      70,
      70,
      71
    ],
    "tentativas": []
  },
  {
    "id": 3,
    "nome": "Manu",
    "media": 78,
    "cores": 78,
    "animais": 71,
    "comidas": 65,
    "evolucao": [
      71,
      71,
      72,
      75,
      77,
      79,
      80,
      81
    ],
    "tentativas": []
  },
  {
    "id": 4,
    "nome": "Lucas",
    "media": 77,
    "cores": 80,
    "animais": 76,
    "comidas": 82,
    "evolucao": [
      67,
      69,
      71,
      73,
      73,
      76,
      76,
      79,
      79
    ],
    "tentativas": []
  },
  {
    "id": 5,
    "nome": "Brenda",
    "media": 81,
    "cores": 80,
    "animais": 85,
    "comidas": 86,
    "evolucao": [
      76,
      77,
      77,
      77,
      78,
      80,
      80,
      81,
      81,
      84
    ],
    "tentativas": []
  },
  {
    "id": 6,
    "nome": "João",
    "media": 93,
    "cores": 94,
    "animais": 91,
    "comidas": 98,
    "evolucao": [
      83,
      84,
      86,
      88,
      89,
      91,
      91,
      92,
      93,
      94,
      97
    ],
    "tentativas": []
  },
  {
    "id": 7,
    "nome": "Luis",
    "media": 90,
    "cores": 95,
    "animais": 95,
    "comidas": 87,
    "evolucao": [
      78,
      80,
      80,
      81,
      81,
      83,
      86,
      88,
      88,
      89,
      91,
      92
    ],
    "tentativas": []
  },
  {
    "id": 8,
    "nome": "Ana",
    "media": 100,
    "cores": 95,
    "animais": 93,
    "comidas": 89,
    "evolucao": [
      86,
      87,
      89,
      90,
      91,
      93,
      96,
      99,
      100,
      100,
      100,
      100,
      100
    ],
    "tentativas": []
  },
  {
    "id": 9,
    "nome": "Rafa",
    "media": 95,
    "cores": 92,
    "animais": 99,
    "comidas": 80,
    "evolucao": [
      76,
      79,
      79,
      82,
      85,
      88,
      90,
      90,
      90,
      92,
      94,
      94,
      96,
      99
    ],
    "tentativas": []
  },
  {
    "id": 10,
    "nome": "Marcos",
    "media": 100,
    "cores": 98,
    "animais": 91,
    "comidas": 92,
    "evolucao": [
      87,
      88,
      88,
      90,
      91,
      92,
      94,
      95,
      95,
      97,
      100,
      100,
      100,
      100,
      100
    ],
    "tentativas": []
  },
  {
    "id": 11,
    "nome": "Julia",
    "media": 100,
    "cores": 100,
    "animais": 100,
    "comidas": 88,
    "evolucao": [
      83,
      83,
      86,
      86,
      87,
      88,
      91,
      92,
      94,
      97,
      98,
      99,
      100,
      100,
      100,
      100
    ],
    "tentativas": []
  },
  {
    "id": 12,
    "nome": "Fernanda",
    "media": 72,
    "cores": 70,
    "animais": 66,
    "comidas": 75,
    "evolucao": [
      63,
      63,
      65,
      65,
      66,
      67,
      67,
      67,
      67,
      68,
      68,
      68,
      70,
      70,
      71,
      73,
      76
    ],
    "tentativas": []
  },
  {
    "id": 13,
    "nome": "Tiago",
    "media": 99,
    "cores": 97,
    "animais": 95,
    "comidas": 90,
    "evolucao": [
      76,
      77,
      80,
      83,
      84,
      84,
      84,
      87,
      89,
      92,
      95,
      98,
      98,
      98,
      98,
      100,
      100,
      100
    ],
    "tentativas": []
  },
  {
    "id": 14,
    "nome": "Carla",
    "media": 96,
    "cores": 97,
    "animais": 87,
    "comidas": 86,
    "evolucao": [
      75,
      76,
      79,
      80,
      82,
      85,
      86,
      86,
      89,
      89,
      89,
      89,
      89,
      90,
      91,
      94,
      97,
      100,
      100
    ],
    "tentativas": []
  },
  {
    "id": 15,
    "nome": "Renato",
    "media": 93,
    "cores": 90,
    "animais": 85,
    "comidas": 97,
    "evolucao": [
      67,
      70,
      72,
      75,
      77,
      80,
      83,
      84,
      85,
      87,
      88,
      88,
      88,
      90,
      90,
      90,
      93,
      94,
      94,
      94
    ],
    "tentativas": []
  }
]
DADOS_TURMA = {
  "media": 88,
  "jogos": 195,
  "maior_evolucao": 18,
  "categorias": {
    "cores": 88,
    "animais": 85,
    "comidas": 84
  },
  "perguntas_erro": [
    {
      "pergunta": "Strawberry",
      "erro_turma": 62
    },
    {
      "pergunta": "Mouse",
      "erro_turma": 48
    },
    {
      "pergunta": "Grape",
      "erro_turma": 41
    }
  ],
  "sugestoes": [
    "Rever vocabulário de Comidas na próxima semana.",
    "Criar atividades extras com: Strawberry, Grape.",
    "Propor atividades extras para alunos com menor média."
  ]
}

@app.route("/")
def dashboard():
    alunos_json = Markup(json.dumps(ALUNOS))
    turma_json = Markup(json.dumps(DADOS_TURMA))
    return render_template(
        "dashboard_tabs.html",
        alunos=ALUNOS,
        dados_turma=DADOS_TURMA,
        alunos_json=alunos_json,
        turma_json=turma_json,
    )

if __name__ == "__main__":
    app.run(debug=True)
