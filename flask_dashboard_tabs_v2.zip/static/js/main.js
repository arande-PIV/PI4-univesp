
let alunos = [];
let turma = {};
let graficoAluno = null;
let graficoTurmaEvolucao = null;

function carregarDados(dadosAlunos, dadosTurma) {
    alunos = dadosAlunos;
    turma = dadosTurma;
    inicializarGraficosTurma();
    popularDropdownAlunos();
    selecionarAluno(alunos[0].id);
    inicializarComparacao();
    inicializarCategoriaTurma();
}

function popularDropdownAlunos() {
    const select = document.getElementById('selectAluno');
    if (!select) return;
    select.innerHTML = '';
    alunos.forEach(a => {
        const opt = document.createElement('option');
        opt.value = a.id;
        opt.textContent = a.nome;
        select.appendChild(opt);
    });
    select.value = alunos[0].id;
}

function inicializarGraficosTurma() {
    const ctxCat = document.getElementById('graficoCategorias');
    if (ctxCat) {
        new Chart(ctxCat, {
            type: 'bar',
            data: {
                labels: ['Cores', 'Animais', 'Comidas'],
                datasets: [{
                    label: 'Acertos (%)',
                    data: [
                        turma.categorias.cores,
                        turma.categorias.animais,
                        turma.categorias.comidas
                    ],
                    borderWidth: 0,
                    backgroundColor: '#2F80ED'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, max: 100 } }
            }
        });
    }

    const ctxEvol = document.getElementById('graficoEvolucaoTurma');
    if (ctxEvol) {
        // Calcula o máximo de tentativas entre os alunos
        const maxLen = Math.max(...alunos.map(a => a.evolucao.length));
        const labels = Array.from({length: maxLen}, (_, i) => (i+1).toString());

        // Gera cores para cada aluno
        const datasets = alunos.map((a, idx) => {
            const padded = Array.from({length: maxLen}, (_, i) => a.evolucao[i] ?? null);
            const hue = (idx * 360 / alunos.length);
            return {
                label: a.nome,
                data: padded,
                borderWidth: 1.5,
                tension: 0.3,
                borderColor: `hsl(${hue}, 70%, 50%)`,
                fill: false,
                pointRadius: 0
            };
        });

        // Calcula média por tentativa
        const mediaData = [];
        for (let i = 0; i < maxLen; i++) {
            const vals = alunos.map(a => a.evolucao[i]).filter(v => v !== undefined);
            const avg = vals.reduce((s,v)=>s+v,0) / vals.length;
            mediaData.push(Math.round(avg));
        }
        datasets.push({
            label: 'Média da turma',
            data: mediaData,
            borderWidth: 3,
            tension: 0.3,
            borderColor: '#111827',
            borderDash: [6,4],
            fill: false,
            pointRadius: 2
        });

        if (graficoTurmaEvolucao) {
            graficoTurmaEvolucao.destroy();
        }

        graficoTurmaEvolucao = new Chart(ctxEvol, {
            type: 'line',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true, max: 100 }
                }
            }
        });
    }
}

function selecionarAluno(id) {
    const aluno = alunos.find(a => a.id === id);
    if (!aluno) return;

    // Sincroniza dropdown
    const select = document.getElementById('selectAluno');
    if (select) {
        select.value = id;
    }

    document.getElementById('alunoNomeTitulo').textContent = aluno.nome;
    document.getElementById('alunoMedia').textContent = aluno.media + '%';
    document.getElementById('alunoCores').textContent = aluno.cores + '%';
    document.getElementById('alunoAnimais').textContent = aluno.animais + '%';
    document.getElementById('alunoComidas').textContent = aluno.comidas + '%';

    const ctx = document.getElementById('graficoEvolucaoAluno');
    if (ctx) {
        if (graficoAluno) {
            graficoAluno.destroy();
        }
        const labels = aluno.evolucao.map((_, i) => (i+1).toString());
        graficoAluno = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Acertos (%)',
                    data: aluno.evolucao,
                    borderWidth: 2,
                    tension: 0.4,
                    borderColor: '#2F80ED',
                    fill: false,
                    pointRadius: 3
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, max: 100 } }
            }
        });
    }
}

function selecionarAlunoDropdown() {
    const select = document.getElementById('selectAluno');
    if (!select) return;
    const id = Number(select.value);
    selecionarAluno(id);
}

function inicializarComparacao() {
    const ctx = document.getElementById('graficoComparacaoAlunos');
    if (!ctx) return;
    const labels = alunos.map(a => a.nome);
    const valores = alunos.map(a => a.media);
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Média (%)',
                data: valores,
                borderWidth: 0,
                backgroundColor: '#2F80ED'
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { x: { beginAtZero: true, max: 100 } }
        }
    });
}

function inicializarCategoriaTurma() {
    const ctx = document.getElementById('graficoRadarCategorias');
    if (!ctx) return;
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Cores', 'Animais', 'Comidas'],
            datasets: [{
                label: 'Turma',
                data: [
                    turma.categorias.cores,
                    turma.categorias.animais,
                    turma.categorias.comidas
                ],
                borderColor: '#2F80ED',
                backgroundColor: 'rgba(47,128,237,0.2)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { r: { beginAtZero: true, max: 100 } }
        }
    });
}
